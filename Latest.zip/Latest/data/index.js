module.exports = {
    provider: require("./provider"),
    seeker: require("./seeker"),
    signin: require("./signin"),
    search:require("./search")
};